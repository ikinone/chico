# README #

### What is this repository for? ###

* ICO information page for Crowdholding.com

### How do I get set up? ###

* clone... done

### Contribution guidelines ###

### Who do I talk to? ###

* henry/chris