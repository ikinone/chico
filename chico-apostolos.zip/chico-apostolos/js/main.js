class chicoCarousel {

    constructor(carouselWrap) {
        this.carouselWrap = carouselWrap;
        this.movement = 0;
    }

    init() {
        this.cacheDom();
        this.bindEvents();
    }

    cacheDom() {
        this.leftButton = this.carouselWrap.find('button.left');
        this.rightButton = this.carouselWrap.find('button.right');
        this.card = this.carouselWrap.find('div.card');
        this.innerCarousel = this.carouselWrap.find('div.inner-carousel');

        this.leftButton.hide();
        this.rightButton.show();
    }

    bindEvents() {
        this.rightButton.click(this.rightClick.bind(this));
        this.leftButton.click(this.leftClick.bind(this));
    }

    rightClick(event) {
        event.preventDefault();
        this.render(true);
    }

    leftClick(event) {
        event.preventDefault();
        this.render(false);
    }

    render(left) {

        if (left) {
            this.movement++;

            if (this.movement > this.card.length - 4) {
                this.movement = this.card.length - 4;
            }
        }

        else {
            this.movement--;
            if (this.movement < 0) {
                this.movement = 0
            }
        }

        this.move();
    }

    buttonRender() {
        if (this.movement <= 0) {
            this.leftButton.hide();
        } else {
            this.leftButton.show();
        }

        if (this.movement >= this.card.length - 4) {
            this.rightButton.hide();
        } else {
            this.rightButton.show();
        }

    }

    move() {
        this.innerCarousel.animate({
            left: (this.movement * (-25)) + '%'
        }, this.buttonRender.bind(this));
    }

}

/* CHICO ->  MODULE FOR ALL PAGE */
const chico = (function () {

    //cache DOM
    const $mobile_toggle = $('#mobile-toggle');
    const $mobile_dropdown = $('#topnavdrop');
    const $navLink = $('.nav-link');
    const $window = $(window);
    const $logo = $('.logo-rot');
    const $body = $('body');
    const $navbar = $('.navbar');
    const $buttomNav = $('#buttomNav');
    const $listIconContainer = $body.find('.list-icon-container');

    //bind events
    $mobile_toggle.on('click', mobileToggle);
    $navLink.on('click', remakeNavLink);
    $window.scroll(windowScroll);
    $logo.hover(logoHoverOn, logoHoverOut);
    

    function init() {
        //init Carousels 
        let teamCarousel = new chicoCarousel($('div.team-carousel'));
        let advisorCarousel = new chicoCarousel($('div.advisors-carousel'));

        teamCarousel.init();
        advisorCarousel.init();

        //logo rotate
        $logo.addClass('rotate');


        // smoothscroll init
        const scroll = new SmoothScroll('a[href*="#"]');

        // clipboard init
        const clipboard = new Clipboard('.clp', {
            container: document.getElementById('key_modal')
        });
    }


    function windowScroll() {
        var scroll = $window.scrollTop();
        if (scroll > 50) {
            $buttomNav.slideDown();
            $navbar.addClass('bg-purple shadow');
            
        } else {
            $buttomNav.slideUp();
            $navbar.removeClass('bg-purple shadow');

        }

    }

    function remakeNavLink() {
        $(this).parent().siblings().find('.nav-link').removeClass('active-link')
        $(this).addClass('active-link');
        $(this).closest('li').siblings().removeClass('active').removeClass('nav-item-active');
        $(this).closest('li').addClass('active').addClass('nav-item-active');

        mobileToggle();
    }

    function mobileToggle() {
        $listIconContainer.toggleClass('change-list-icon');
        $mobile_dropdown.slideToggle(300);
        $body.toggleClass('overflower');
    }


    /* LOGO HOVER FUNCTIONS */

    function logoHoverOn() {
        if ($window.width() > 1023) {
            $logo.removeClass("rotate");
        }
    }

    function logoHoverOut() {
        if ($window.width() > 1023) {
            $logo.addClass("rotate");
        }
    }
    
    //initialize 
    init();


    //HOME SECTION TIMER 
    const chicoTimer = {

        init: function () {
            this.setVariables();
            this.cacheDom();

            // saleEndDuration = time remaining to ICO START
            // if negative, ICO has started and we must countdown the ICO END
            if (this.saleEndDuration.asDays() >= 0) {
                this.switchSections('PREICO')
            } else {
                this.switchSections('ICO')
            }

            // main page init
            this.setCurrentBonus();
            this.startCountDownRender();
        },

        setVariables: function () {

            this.TOKEN_SALE_STARTS_IN = "2017-11-01 10:00:00"; // YYYY-MM-DD HH:mm:ss
            this.TOKEN_SALE_END_IN = "2017-12-01 22:00:00"; // YYYY-MM-DD HH:mm:ss
            this.TIMEZONE = "UTC"; // +2
            this.SALE_MONTH = "11"; // 11.
            this.TIME_REMAINING_REFRESH_TIME = 1000; // ms - sale time will be refreshed
            this.SALE_MILESTONES = [
                {
                    date: "2017-" + (parseInt(this.SALE_MONTH) + 1) + "-03 10:00:00",
                    percent: 0
                },
                {
                    date: "2017-" + this.SALE_MONTH + "-16 10:00:00",
                    percent: 10
                },
                {
                    date: "2017-" + this.SALE_MONTH + "-06 10:00:00",
                    percent: 20
                }
            ];

            // Count Sale End Duration
            this.now = moment.tz(this.TIMEZONE);
            this.end = moment.tz(this.TOKEN_SALE_STARTS_IN, this.TIMEZONE);
            this.msDifference = this.end.diff(this.now);
            this.saleEndDuration = moment.duration(this.msDifference);

            if (this.msDifference < 0) this.msDifference = 0;

        },

        cacheDom: function () {

            this.$home = $('#home');

            //var countDownTimer = document.getElementById('countdown-timer');
            //var currentBonusPercent = document.getElementById('current-bonus-percent');
            //var currentBonusDays = document.getElementById('current-bonus-days');
            this.$countdownDays = this.$home.find('#countdown-days');
            this.$countdownHours = this.$home.find('#countdown-hours');
            this.$countdownMins = this.$home.find('#countdown-mins');
            this.$countdownSec = this.$home.find('#countdown-sec');

        },

        addPadding: function (str) {
            if (str.toString().length < 2) {
                return "0" + str;
            }
            return str;
        },

        // switch section: hide/show elements and set counter to END
        switchSections: function (period) {
            //console.log('switch Section' + period);
            if (period == 'PREICO') {
                // hide old section and show new
                $('.cta-show-icostart').hide();
                $('.cta-hide-icostart').show();

            } else {
                // hide new section and show old
                $('.cta-show-icostart').show();
                $('.cta-hide-icostart').hide();
                $('#main-title-ico').html('YUPIE ICO<br>now LIVE!');

                // Set counter on Sale End Duration
                this.end = moment.tz(this.TOKEN_SALE_END_IN, this.TIMEZONE);
                this.msDifference = this.end.diff(this.now);
                this.saleEndDuration = moment.duration(this.msDifference);
                if (this.msDifference < 0) this.msDifference = 0;
            }
        },

        reRenderCountDown: function () {
            this.$countdownDays.text(this.addPadding(Math.floor(this.saleEndDuration.asDays())));
            this.$countdownHours.text(this.addPadding(Math.floor(this.saleEndDuration.hours())));
            this.$countdownMins.text(this.addPadding(Math.floor(this.saleEndDuration.minutes())));
            this.$countdownSec.text(this.addPadding(Math.floor(this.saleEndDuration.seconds())));

            if (
                this.saleEndDuration.days() === 0 &&
                this.saleEndDuration.hours() === 0 &&
                this.saleEndDuration.minutes() === 0 &&
                this.saleEndDuration.seconds() === 0
            ) {
                this.switchSections('ICO');
                return;
            }
            if (this.saleEndDuration.asDays() < 0) {
                //console.log('should not be here unless ICO has ended');
            }

            this.saleEndDuration.subtract(1, "s");
        },
        startCountDownRender: function () {
            this.reRenderCountDown();
            setInterval(this.reRenderCountDown.bind(this), this.TIME_REMAINING_REFRESH_TIME);
        },
        setCurrentBonus: function () {
            var percentage = 20;
            var daysLeft;
            var hoursLeft;
            var minLeft;
            var secLeft;
            var prevDif;
            jQuery.each(this.SALE_MILESTONES, function (key, bonus) {

                var now = moment.tz(this.TIMEZONE);
                var bonusDateEnd = moment.tz(bonus.date, this.TIMEZONE);
                var msDifference = bonusDateEnd.diff(now);
                var bonusEndDuration = moment.duration(msDifference);
                if (msDifference < 0) msDifference = 0;

                if (bonusEndDuration.asDays() >= 0) {
                    percentage = bonus.percent;
                    daysLeft = Math.ceil(bonusEndDuration.asDays());
                    hoursLeft = Math.ceil(bonusEndDuration.hours());
                    minLeft = Math.ceil(bonusEndDuration.minutes());
                    secLeft = Math.ceil(bonusEndDuration.seconds() + 60 * bonusEndDuration.minutes());
                }
            });
            if (percentage > 0) {

                this.$currentBonusDays = $('#current-bonus-days');
                this.$currentBonusPercentage = $("#current-bonus-percent");
                this.$bonusTable = $('.bonus-table');

                if (daysLeft > 1) {
                    this.$currentBonusDays.text("Lowers in " + daysLeft + " days");
                } else if (hoursLeft > 1) {
                    this.$currentBonusDays.text("Lowers in " + hoursLeft + " hours");
                } else if (minLeft > 1) {
                    this.$currentBonusDays.text("Lowers in " + minLeft + " minutes");
                } else if (secLeft > 0) {
                    this.$currentBonusDays.text("Lowers in " + secLeft + " seconds");
                }
                this.$currentBonusDays.text(percentage + "%");
            } else {
                this.$bonusTable.hide();
            }
        },

    };
    chicoTimer.init();

})();




(function () {
   
    //CHARTS 

    // bonus by value

    // var ctx = document.getElementById("valuechart").getContext('2d');
    // var myChart = new Chart(ctx, {
    //     type: 'bar',
    //     data: {
    //         labels: [0, 1, 6, 25],
    //         datasets: [{
    //             label: 'YUPIE bonus %',
    //             data: [0, 5, 10, 15],
    //             backgroundColor: 'rgba(256, 59, 63, 0.2)',
    //             borderColor: 'rgba(256, 59, 63, 1)',
    //             borderWidth: 2
    //         }]
    //     },
    //     options: {
    //         legend: {
    //             display: true,
    //             labels: {
    //                 fontColor: '#F8F9FA'
    //             }
    //         },
    //         scales: {
    //             yAxes: [{
    //                 display: false,
    //             }],
    //             xAxes: [{
    //                 ticks: {
    //                     fontColor: '#F8F9FA',
    //                 },
    //                 gridLines: {
    //                     color: '#F8F9FA',
    //                     display: false,
    //                 },
    //                 scaleLabel: {
    //                     display: true,
    //                     labelString: 'minimum ETH value of investment',
    //                     fontColor: '#F8F9FA',
    //                 }
    //             }]
    //         },
    //         plugins: {
    //             datalabels: {
    //                 color: '#F8F9FA',
    //             }
    //         }
    //     }
    // });

    // bonus by time

    // var ctx = document.getElementById("timechart").getContext('2d');
    // var myChart = new Chart(ctx, {
    //     type: 'bar',
    //     data: {
    //         labels: ["05/11", "15/11", "01/12"],
    //         datasets: [{
    //             label: 'YUPIE bonus %',
    //             data: [20, 10, 0],
    //             backgroundColor: 'rgba(256, 59, 63, 0.2)',
    //             borderColor: 'rgba(256, 59, 63, 1)',
    //             borderWidth: 2
    //         }]
    //     },
    //     options: {
    //         legend: {
    //             display: true,
    //             labels: {
    //                 fontColor: '#F8F9FA'
    //             }
    //         },
    //         scales: {
    //             yAxes: [{
    //                 display: false,
    //             }],
    //             xAxes: [{
    //                 ticks: {
    //                     fontColor: '#F8F9FA',
    //                 },
    //                 gridLines: {
    //                     color: '#F8F9FA',
    //                     display: false,
    //                 },
    //                 scaleLabel: {
    //                     display: true,
    //                     labelString: 'Invest by this date',
    //                     fontColor: '#F8F9FA',
    //                 }
    //             }]
    //         },
    //         plugins: {
    //             datalabels: {
    //                 color: '#F8F9FA',
    //             }
    //         }
    //     }
    // });

    // token distribution
    var ctx = document.getElementById("tokenchart").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Pre-ICO', 'Bounties', 'Seeding businesses', 'YUPIE reserve', 'Locked for future use', 'Team & experts', 'ICO'],
            datasets: [{
                label: '% of total tokens',
                data: [0.8, 1, 5, 10, 19, 20, 44.2],
                backgroundColor: ['rgba(91, 192, 235, 0.2)', 'rgba(255, 231, 76, 0.2)', 'rgba(243, 117, 43, 0.2)', 'rgba(243, 167, 18, 0.2)', 'rgba(168, 198, 134, 0.2)', 'rgba(192, 215, 234, 0.2)', 'rgba(256, 59, 63, 0.2)'],
                borderColor: ['rgba(91, 192, 235, 1)', 'rgba(255, 231, 76, 1)', 'rgba(243, 117, 43, 1)', 'rgba(243, 167, 18, 1)', 'rgba(168, 198, 134, 1)', 'rgba(192, 215, 234, 1)', 'rgba(256, 59, 63, 1)'],
                borderWidth: 2
            }]
        },
        options: {
            legend: {
                display: true,
                labels: {
                    fontColor: '#F8F9FA'
                }
            },
            scales: {
                yAxes: [{
                    display: false,
                }],
                xAxes: [{
                    display: false,
                    ticks: {
                        fontColor: '#F8F9FA',
                    },
                    gridLines: {
                        color: '#F8F9FA',
                        display: false,
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'ETH value of investment',
                        fontColor: '#F8F9FA',
                    }
                }]
            },
            plugins: {
                datalabels: {
                    color: '#F8F9FA',
                    display: function (context) {
                        return context.dataIndex > 0.9; // display labels with an odd index
                    },
                    font: {
                        // size: 16
                    },
                }
            }
        }
    });
    
})();

// mailchimp heroku app
(function ($) {
    "use strict";
    $.mailchimpSingleOptIn = {
        init: function (selector, options) {
            $(selector).mailchimpSingleOptIn(options);
        }
    };
    $.fn.mailchimpSingleOptIn = function (options) {
        // console.log($(this));
        $(this).each(function (i, elem) {
            let form = $(elem);
            let email = form.find("input[type=email]");
            let settings = $.extend({
                onSubmit() { },
                onError() { },
                onSuccess() { }
            },
                options
            );
            //form.attr('novalidate', 'true');
            email.attr("name", "email");
            form.submit(function (e) {
                e.preventDefault();
                let data = {
                    list_id: settings.listID
                };
                let dataArray = form.serializeArray();
                $.each(dataArray, function (index, item) {
                    data[item.name] = item.value;
                });
                //console.log(settings.onSuccess);
                //console.log(settings.onError);

                if (!data.email) {
                    form[0].checkValidity();
                }
                settings.onSubmit();
                $.ajax({
                    method: "POST",
                    url: settings.url,
                    data: data,
                    success: settings.onSuccess,
                    error: settings.onError
                });
            });
        });
        return this;
    };
})(jQuery);

function ga() { }
Alert = {
    show: function ($div, msg, n) {
        // console.log("show" + n + msg);
        $div.find(".thanks-msg" + n).text(msg);
        if ($div.css("display") === "none") {
            $div
                .fadeIn(300)
                .delay(4000)
                .fadeOut(500);
        }
    },
    thank: function (msg, n) {
        this.show($("#thanks" + n), msg, n);
    }
};
$("#mailchimp-form").mailchimpSingleOptIn({
    listID: "eaf16b84b5",
    url: "https://ch-ico-sub.herokuapp.com/",
    onSubmit: function () {
        // console.log("sent email 1");
    },
    onError: function (request) {
        if (request.responseJSON) {
            Alert.thank(
                request.responseJSON.title + ":" + request.responseJSON.detail,
                1
            );
        } else {
            Alert.thank("Error, but Thanks for signing up!", 1);
        }
    },
    onSuccess: function (request) {
        if (request.responseJSON) {
            Alert.thank(
                request.responseJSON.title + ":" + request.responseJSON.detail,
                1
            );
        } else {
            Alert.thank("Thanks for signing up!", 1);
        }
    }
});
$("#mailchimp-form2").mailchimpSingleOptIn({
    listID: "eaf16b84b5",
    url: "https://ch-ico-sub.herokuapp.com/",
    onSubmit: function () {
        // console.log("sent email 2");
    },
    onError: function (request) {
        if (request.responseJSON) {
            Alert.thank(
                request.responseJSON.title + ":" + request.responseJSON.detail,
                1
            );
        } else {
            Alert.thank("Error, but Thanks for signing up!", 2);
        }
    },
    onSuccess: function (request) {
        if (request.responseJSON) {
            Alert.thank(
                request.responseJSON.title + ":" + request.responseJSON.detail,
                1
            );
        } else {
            Alert.thank("Thanks for signing up!", 2);
        }
    }
});

